# Work Tracker — Next.js (Accounts + Persistent Storage)

## Quick start
```bash
npm install
npm run dev
```
Then open http://localhost:3000

- **Sign Up / Log In** to create/find your account.
- Toggle **Use Server** on the sign-in screen. If unchecked or server is unreachable, data stores in your browser.
- Data is saved in `db.json` at the project root when using server mode (dev demo).

## API routes
- `GET /api/health` — health check
- `POST /api/signup { email, password, fullName }`
- `POST /api/login { email, password }`
- `GET /api/data` (Bearer token)
- `PUT /api/data` (Bearer token) — `{ profile, contracts, sessions }`
- `DELETE /api/data` (Bearer token) — reset

## Notes
- Demo JWT secret is `dev-secret-change-me`. Set `JWT_SECRET` in env for production.
- File I/O persistence via `db.json` works in `npm run dev`. For production use a real database.


## Password reset & Email verification
- **Request verification:** `POST /api/request-verify { email }` → email with link to `/api/verify?token=...`
- **Request password reset:** `POST /api/request-reset { email }` → email with link to `/reset?token=...`
- **Complete reset:** `POST /api/reset { token, password }`

### Email setup
1. Copy `.env.example` to `.env.local` and fill SMTP settings (Ethereal works great for testing).
2. Start the app. If SMTP is not configured, emails will be **logged to the console** (fallback).

### Security notes
- Tokens expire after 30 minutes.
- Do not keep `JWT_SECRET` default in production.
- Use HTTPS and a real database if you deploy.
