import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

export function sign(uid: string) {
  return jwt.sign({ uid }, JWT_SECRET, { expiresIn: '30d' });
}

export function verify(token: string): { uid: string } {
  return jwt.verify(token, JWT_SECRET) as any;
}
