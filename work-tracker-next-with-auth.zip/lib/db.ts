import fs from 'fs';
import path from 'path';

const DB_FILE = path.resolve(process.cwd(), 'db.json');

type User = { id: string, email: string, fullName?: string, passHash: string };
type Data = { profile: any, contracts: any[], sessions: any[] };

type Token = { id: string, uid: string, type: 'verify'|'reset', expiresAt: number };

type DB = { users: User[], data: Record<string, Data>, tokens: Token[] };

export function readDB(): DB {
  if (!fs.existsSync(DB_FILE)) {
    const initial: DB = { users: [], data: {}, tokens: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}

export function writeDB(db: DB) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
