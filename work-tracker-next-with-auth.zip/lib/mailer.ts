import nodemailer from 'nodemailer';
const {
  SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS, MAIL_FROM, APP_BASE_URL
} = process.env;

export async function sendMail(to: string, subject: string, html: string) {
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) {
    console.log('\n[MAIL FALLBACK] Would send email to:', to);
    console.log('Subject:', subject);
    console.log('HTML:\n', html);
    return { ok: true, info: { fallback: true } };
  }
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT || 587),
    secure: String(SMTP_SECURE||'false') === 'true',
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
  const info = await transporter.sendMail({
    from: MAIL_FROM || 'no-reply@work-tracker.local',
    to,
    subject,
    html,
  });
  return { ok: true, info };
}

export function appUrl(pathname: string) {
  const base = APP_BASE_URL || 'http://localhost:3000';
  return base.replace(/\/$/, '') + pathname;
}
