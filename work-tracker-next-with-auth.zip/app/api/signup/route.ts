import { NextRequest } from 'next/server';
import bcrypt from 'bcryptjs';
import { nanoid } from 'nanoid';
import { readDB, writeDB } from '@/lib/db';
import { sign } from '@/lib/jwt';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { email, password, fullName } = body || {};
  if (!email || !password) return new Response('Email and password required', { status: 400 });

  const db = readDB();
  if (db.users.find(u => u.email === email)) return new Response('Email already registered', { status: 409 });

  const passHash = await bcrypt.hash(password, 10);
  const user = { id: nanoid(), email, fullName: fullName || '', passHash };
  db.users.push(user);
  db.data[user.id] = { profile: { fullName: fullName || '', city: '', email, phone: '', username: '', password: '' }, contracts: [], sessions: [] };
  writeDB(db);

  const token = sign(user.id);
  return Response.json({ user: { id: user.id, email: user.email, fullName: user.fullName }, token });
}
