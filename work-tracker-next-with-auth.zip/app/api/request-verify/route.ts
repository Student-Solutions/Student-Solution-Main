import { NextRequest } from 'next/server';
import { readDB, writeDB } from '@/lib/db';
import { nanoid } from 'nanoid';
import { sendMail, appUrl } from '@/lib/mailer';

export async function POST(req: NextRequest) {
  const { email } = await req.json() || {};
  if (!email) return new Response('Email required', { status: 400 });
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user) return new Response('OK', { status: 200 }); // don't leak
  const tokenId = nanoid();
  const expiresAt = Date.now() + 1000*60*30; // 30 min
  db.tokens.push({ id: tokenId, uid: user.id, type: 'verify', expiresAt });
  writeDB(db);
  const link = appUrl(`/api/verify?token=${tokenId}`);
  await sendMail(email, 'Verify your email', `<p>Click to verify: <a href="${link}">${link}</a></p>`);
  return Response.json({ ok: true });
}
