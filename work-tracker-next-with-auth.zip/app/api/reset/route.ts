import { NextRequest } from 'next/server';
import { readDB, writeDB } from '@/lib/db';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  const { token, password } = await req.json() || {};
  if (!token || !password) return new Response('Missing token or password', { status: 400 });
  const db = readDB();
  const idx = db.tokens.findIndex(t => t.id === token && t.type === 'reset');
  if (idx === -1) return new Response('Invalid token', { status: 400 });
  const t = db.tokens[idx];
  if (Date.now() > t.expiresAt) return new Response('Token expired', { status: 400 });
  const user = db.users.find(u => u.id === t.uid);
  if (!user) return new Response('User not found', { status: 404 });
  user.passHash = await bcrypt.hash(password, 10);
  db.tokens.splice(idx, 1);
  writeDB(db);
  return Response.json({ ok: true });
}
