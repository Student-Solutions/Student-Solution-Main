import { NextRequest } from 'next/server';
import bcrypt from 'bcryptjs';
import { readDB } from '@/lib/db';
import { sign } from '@/lib/jwt';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { email, password } = body || {};
  if (!email || !password) return new Response('Email and password required', { status: 400 });

  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user) return new Response('Invalid credentials', { status: 401 });
  const ok = await (user?.passHash ? import('bcryptjs').then(m => m.default.compare(password, user.passHash)) : Promise.resolve(false));
  if (!ok) return new Response('Invalid credentials', { status: 401 });

  const token = sign(user.id);
  return Response.json({ user: { id: user.id, email: user.email, fullName: user.fullName }, token });
}
