import { NextRequest } from 'next/server';
import { readDB, writeDB } from '@/lib/db';
import { verify } from '@/lib/jwt';

function getUid(req: NextRequest): string | null {
  const auth = req.headers.get('authorization') || '';
  const m = auth.match(/^Bearer (.+)$/);
  if (!m) return null;
  try {
    const payload = verify(m[1]);
    return payload.uid;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const uid = getUid(req);
  if (!uid) return new Response('No/invalid token', { status: 401 });
  const db = readDB();
  const d = db.data[uid] || { profile: {}, contracts: [], sessions: [] };
  return Response.json(d);
}

export async function PUT(req: NextRequest) {
  const uid = getUid(req);
  if (!uid) return new Response('No/invalid token', { status: 401 });
  const body = await req.json();
  const { profile, contracts, sessions } = body || {};
  const db = readDB();
  db.data[uid] = { profile: profile || {}, contracts: contracts || [], sessions: sessions || [] };
  writeDB(db);
  return Response.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const uid = getUid(req);
  if (!uid) return new Response('No/invalid token', { status: 401 });
  const db = readDB();
  db.data[uid] = { profile: { fullName:'', city:'', email:'', phone:'', username:'', password:'' }, contracts: [], sessions: [] };
  writeDB(db);
  return Response.json({ ok: true });
}
