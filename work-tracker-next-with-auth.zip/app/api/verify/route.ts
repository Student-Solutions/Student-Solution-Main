import { NextRequest } from 'next/server';
import { readDB, writeDB } from '@/lib/db';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const tokenId = searchParams.get('token');
  if (!tokenId) return new Response('Missing token', { status: 400 });
  const db = readDB();
  const idx = db.tokens.findIndex(t => t.id === tokenId && t.type === 'verify');
  if (idx === -1) return new Response('Invalid token', { status: 400 });
  const token = db.tokens[idx];
  if (Date.now() > token.expiresAt) return new Response('Token expired', { status: 400 });
  // mark verified: add a flag on user profile
  const userData = db.data[token.uid] || { profile:{}, contracts:[], sessions:[] };
  userData.profile = { ...userData.profile, emailVerified: true };
  db.data[token.uid] = userData;
  db.tokens.splice(idx, 1);
  writeDB(db);
  return new Response('<html><body>Email verified! You can close this tab.</body></html>', { headers: { 'Content-Type':'text/html' } });
}
