
'use client';
import React, { useEffect, useMemo, useState } from 'react';

type Session = { mode: 'server'|'local', token: string|null, userId: string };
const emptyProfile = { fullName:'', city:'', email:'', phone:'', username:'', password:'' };
const CONTRACT_TYPES = ['Mini-Job','Werkstudent','Part-Time','Full-Time','Freelancer','Internship','Other'];

function uid(prefix='id'){ return `${prefix}_${Math.random().toString(36).slice(2,8)}_${Date.now().toString(36)}`; }
function genUsername(fullName?:string, email?:string){
  const base = (fullName || email || 'user').toLowerCase().replace(/[^a-z0-9]+/g,'.').replace(/^\.|\.?$/g,'');
  return `${base}.${Math.floor(Math.random()*900+100)}`;
}
function genPassword(){
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  return Array.from({length:12}, ()=>chars[Math.floor(Math.random()*chars.length)]).join('');
}
function toCurrency(n:any){ const v = Number(n||0); return new Intl.NumberFormat(undefined,{style:'currency', currency:'EUR'}).format(v); }
function distinctDays(s:any[]){ return new Set(s.map(x=>x.date)).size; }

async function pingServer(){ try{ const r = await fetch('/api/health'); return r.ok; } catch { return false; } }
async function api(path:string, method='GET', body?:any, token?:string|null){
  const headers:any = { 'Content-Type':'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function Input({label, value, onChange, type='text', step}:{label:string,value:any,onChange:(v:any)=>void,type?:string,step?:any}){
  return (<label><div className="label">{label}</div><input className="input" value={value} onChange={e=>onChange((e.target as HTMLInputElement).value)} type={type} step={step}/></label>);
}
function Select({label, value, onChange, options}:{label:string,value:any,onChange:(v:any)=>void,options:any[]}){
  const opts = (options||[]).map(o=> typeof o==='string'?{label:o,value:o}:o);
  return (<label><div className="label">{label}</div><select className="select" value={value} onChange={e=>onChange((e.target as HTMLSelectElement).value)}>{opts.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></label>);
}

function AuthPage({ onAuthed }:{ onAuthed:(s:Session)=>void }){
  const [mode,setMode] = useState<'login'|'signup'>('login');
  const [serverAvailable,setServerAvailable] = useState(false);
  const [useServer,setUseServer] = useState(true);
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [fullName,setFullName] = useState('');
  const [error,setError] = useState('');

  useEffect(()=>{ (async()=>setServerAvailable(await pingServer()))(); },[]);

  async function handleSubmit(e:any){
    e.preventDefault(); setError('');
    if (!serverAvailable || !useServer) {
      const localUserId = email || 'local-user';
      return onAuthed({ mode:'local', token:null, userId: localUserId });
    }
    try{
      if (mode==='signup'){
        const out = await api('/api/signup','POST',{ email, password, fullName });
        onAuthed({ mode:'server', token: out.token, userId: out.user.id });
      } else {
        const out = await api('/api/login','POST',{ email, password });
        onAuthed({ mode:'server', token: out.token, userId: out.user.id });
      }
    }catch(err:any){ setError(err.message || String(err)); }
  }

  return (
    <div className="container center">
      <div className="card" style={{width:420}}>
        <h1 style={{marginTop:0}}>Work Tracker</h1>
        <div className="card" style={{padding:12}}>
          <div className="toolbar" style={{justifyContent:'space-between'}}>
            <div>
              <div className="small">Server: {serverAvailable ? 'Available' : 'Not reachable'}</div>
            </div>
            <label className="small"><input type="checkbox" checked={useServer && serverAvailable} onChange={e=>setUseServer((e.target as HTMLInputElement).checked)} disabled={!serverAvailable}/> Use Server</label>
          </div>
          <div className="small">If off, data saves to your browser only.</div>
        </div>

        <div className="toolbar" style={{marginTop:12}}>
          <button className={`btn ${mode==='login'?'primary':'ghost'}`} onClick={()=>setMode('login')}>Log In</button>
          <button className={`btn ${mode==='signup'?'primary':'ghost'}`} onClick={()=>setMode('signup')}>Sign Up</button>
        </div>

        <form onSubmit={handleSubmit} style={{marginTop:12, display:'grid', gap:8}}>
          {mode==='signup' && <Input label="Full Name" value={fullName} onChange={setFullName}/>}
          <Input label="Email" value={email} onChange={setEmail} />
          <Input label="Password" value={password} onChange={setPassword} type="password" />
          {error && <div className="small" style={{color:'#b91c1c'}}> {error} </div>}
          <button className="btn primary" type="submit">{mode==='signup'?'Create Account':'Log In'}</button>
        </form>
      </div>
    </div>
  );
}

export default function Page(){
  const [session,setSession] = useState<Session|null>(null);
  const [profile,setProfile] = useState<any>(emptyProfile);
  const [contracts,setContracts] = useState<any[]>([]);
  const [sessions,setSessions] = useState<any[]>([]);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState('');

  useEffect(()=>{ (async()=>{
    if (!session) return;
    setLoading(true); setNotice('');
    try{
      if (session.mode==='server'){
        const out = await api('/api/data','GET',undefined, session.token);
        setProfile(out.profile||emptyProfile); setContracts(out.contracts||[]); setSessions(out.sessions||[]);
      } else {
        const raw = localStorage.getItem('workTrackerData_'+session.userId);
        if (raw){ const parsed = JSON.parse(raw); setProfile(parsed.profile||emptyProfile); setContracts(parsed.contracts||[]); setSessions(parsed.sessions||[]); }
        else { setProfile(emptyProfile); setContracts([]); setSessions([]); }
      }
    }catch(e:any){ setNotice('Load failed: '+(e.message||String(e))); }
    finally{ setLoading(false); }
  })(); },[session]);

  useEffect(()=>{ (async()=>{
    if (!session) return;
    const payload = { profile, contracts, sessions };
    try{
      if (session.mode==='server'){
        await api('/api/data','PUT',payload, session.token);
      } else {
        localStorage.setItem('workTrackerData_'+session.userId, JSON.stringify(payload));
      }
    }catch(e:any){ setNotice('Auto-save failed: '+(e.message||String(e))); }
  })(); },[profile,contracts,sessions]);

  function exportCSV(){
    const header = ["Full Name","City","Email","Phone","Username","Contract Name","Contract Type","Hourly Rate","Date","Hours","Earnings"];
    const rows = sessions.map(s=>{ const c = contracts.find(x=>x.id===s.contractId)||{}; const earnings = Number(s.hours||0)*Number(c.hourly||0); return [profile.fullName,profile.city,profile.email,profile.phone,profile.username,c.name||"",c.contractType||"",c.hourly??"",s.date,s.hours,earnings]; });
    const all = [header, ...rows];
    const csv = all.map(r=>r.map(x=>`"${String(x??"").replace(/"/g,'""')}"`).join(",")).join("\\n");
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download=`work-tracker_${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url);
  }

  const totals = useMemo(()=>{
    const byContract = new Map<string,{hours:number,earnings:number,days:number}>();
    for (const c of contracts) byContract.set(c.id, { hours:0, earnings:0, days:0 });
    for (const c of contracts){
      const sess = sessions.filter(s=>s.contractId===c.id);
      const hours = sess.reduce((a,b)=>a+Number(b.hours||0),0);
      const earnings = hours*Number(c.hourly||0);
      const days = distinctDays(sess);
      byContract.set(c.id, { hours, earnings, days });
    }
    const totalHours = Array.from(byContract.values()).reduce((a,b)=>a+b.hours,0);
    const totalEarnings = Array.from(byContract.values()).reduce((a,b)=>a+b.earnings,0);
    const totalDays = distinctDays(sessions);
    return { byContract, totalHours, totalEarnings, totalDays };
  },[contracts,sessions]);

  function resetAll(){
    if (!confirm('Clear all saved data?')) return;
    setProfile(emptyProfile); setContracts([]); setSessions([]);
    if (session?.mode==='local') localStorage.removeItem('workTrackerData_'+session.userId);
  }

  if (!session) return <AuthPage onAuthed={setSession}/>;
  if (loading) return <div className="center">Loading…</div>;

  return (
    <div>
      <header style={{position:'sticky', top:0, background:'#fff', borderBottom:'1px solid #e5e7eb', zIndex:10}}>
        <div className="container" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{display:'flex', alignItems:'center', gap:8}}>
            <h2 style={{margin:0}}>Work Tracker</h2>
            <span className="badge">{session.mode==='server'?'Server Storage':'Local Storage'}</span>
          </div>
          <div className="toolbar">
            <button className="btn ghost" onClick={()=>setSession(null)}>Sign Out</button>
            <button className="btn warn" onClick={resetAll}>Reset</button>
          </div>
        </div>
        {notice && <div className="container small" style={{paddingTop:6}}>{notice}</div>}
      </header>

      <main className="container" style={{display:'grid', gap:24}}>
        <section className="card">
          <h3>User Details</h3>
          <div className="row">
            <Input label="Full Name" value={profile.fullName} onChange={v=>setProfile({...profile,fullName:v})}/>
            <Input label="City" value={profile.city} onChange={v=>setProfile({...profile,city:v})}/>
            <Input label="Email" value={profile.email} onChange={v=>setProfile({...profile,email:v})} />
            <Input label="Phone" value={profile.phone} onChange={v=>setProfile({...profile,phone:v})} />
          </div>
          <div className="toolbar" style={{marginTop:12, flexWrap:'wrap', gap:12}}>
            <Input label="Username" value={profile.username} onChange={v=>setProfile({...profile,username:v})}/>
            <Input label="Password" value={profile.password} onChange={v=>setProfile({...profile,password:v})}/>
            <button className="btn primary" onClick={()=>setProfile(p=>({...p, username: genUsername(p.fullName,p.email), password: genPassword()}))}>Generate Login</button>
          </div>
        </section>

        <section className="card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>Job Contracts</h3>
            <button className="btn primary" onClick={()=>setContracts(prev=>[...prev,{id:uid('contract'),name:'',contractType:CONTRACT_TYPES[0],hourly:0}])}>Add Contract</button>
          </div>
          {!contracts.length && <div className="small">No contracts yet. Click "Add Contract" to create one.</div>}
          <div style={{display:'grid', gap:12}}>
            {contracts.map(c=>(
              <div key={c.id} className="card" style={{padding:12}}>
                <div className="row" style={{gridTemplateColumns:'repeat(4, minmax(0,1fr))'}}>
                  <Input label="Contract Name (Job)" value={c.name} onChange={v=>setContracts(prev=>prev.map(x=>x.id===c.id?{...x,name:v}:x))}/>
                  <Select label="Contract Type" value={c.contractType} onChange={v=>setContracts(prev=>prev.map(x=>x.id===c.id?{...x,contractType:v}:x))} options={CONTRACT_TYPES}/>
                  <Input label="Hourly Rate (€)" value={c.hourly} onChange={v=>setContracts(prev=>prev.map(x=>x.id===c.id?{...x,hourly:Number(v)}:x))} type="number" step="0.01"/>
                  <div style={{display:'flex', alignItems:'end', justifyContent:'end'}}>
                    <button className="btn" style={{background:'#fee2e2', color:'#991b1b'}} onClick={()=>{ setContracts(prev=>prev.filter(x=>x.id!==c.id)); setSessions(prev=>prev.filter(s=>s.contractId!==c.id)); }}>Remove</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>Work Sessions</h3>
            <button className="btn primary" onClick={()=>{
              if (!contracts.length) return alert('Please create a contract first.');
              const firstId = contracts[0].id;
              setSessions(prev=>[...prev,{id:uid('session'),contractId:firstId,date:new Date().toISOString().slice(0,10),hours:0}]);
            }}>Add Session</button>
          </div>
          {!contracts.length && <div className="small">Create at least one contract to log sessions.</div>}
          <div style={{display:'grid', gap:12}}>
            {sessions.map(s=>(
              <div key={s.id} className="card" style={{padding:12}}>
                <div className="row" style={{gridTemplateColumns:'repeat(5, minmax(0,1fr))'}}>
                  <Select label="Contract" value={s.contractId} onChange={v=>setSessions(prev=>prev.map(x=>x.id===s.id?{...x,contractId:v}:x))} options={contracts.map(c=>({label:`${c.name||'(unnamed)'} — ${c.contractType}`, value:c.id}))}/>
                  <Input label="Date" value={s.date} onChange={v=>setSessions(prev=>prev.map(x=>x.id===s.id?{...x,date:v}:x))} type="date"/>
                  <Input label="Hours" value={s.hours} onChange={v=>setSessions(prev=>prev.map(x=>x.id===s.id?{...x,hours:Number(v)}:x))} type="number" step="0.25"/>
                  <div>
                    {(()=>{ const c = contracts.find(c=>c.id===s.contractId); const earnings = (Number(s.hours||0)*Number(c?.hourly||0))||0; return (
                      <div className="card" style={{padding:10, background:'#f9fafb'}}>
                        <div>Earnings: <b>{toCurrency(earnings)}</b></div>
                        <div className="small">@ {toCurrency(c?.hourly||0)}/hr</div>
                      </div>
                    )})()}
                  </div>
                  <div style={{display:'flex', justifyContent:'end', alignItems:'end'}}>
                    <button className="btn" style={{background:'#fee2e2', color:'#991b1b'}} onClick={()=>setSessions(prev=>prev.filter(x=>x.id!==s.id))}>Remove</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3>Summary & Tables</h3>
            <div className="toolbar"><button className="btn ghost" onClick={exportCSV}>Export CSV</button></div>
          </div>
          <div className="row">
            <div className="card">
              <h4 style={{marginTop:0}}>User</h4>
              <div className="small">Name: {profile.fullName||'—'}</div>
              <div className="small">City: {profile.city||'—'}</div>
              <div className="small">Email: {profile.email||'—'}</div>
              <div className="small">Phone: {profile.phone||'—'}</div>
              <div className="small">Username: {profile.username||'—'}</div>
            </div>
            <div className="card">
              <h4 style={{marginTop:0}}>Overall Totals</h4>
              <div className="small">Distinct Days Worked: {totals.totalDays}</div>
              <div className="small">Total Hours: {totals.totalHours.toFixed(2)}</div>
              <div className="small">Total Earnings: <b>{toCurrency(totals.totalEarnings)}</b></div>
            </div>
          </div>
          <div style={{overflowX:'auto', marginTop:12}}>
            <table className="table">
              <thead><tr><th>Contract</th><th>Type</th><th>Hourly (€)</th><th>Days</th><th>Hours</th><th>Earnings</th></tr></thead>
              <tbody>
                {contracts.map(c=>{ const t = totals.byContract.get(c.id) || {hours:0,earnings:0,days:0}; return (
                  <tr key={c.id}><td>{c.name||'(unnamed)'}</td><td>{c.contractType}</td><td>{Number(c.hourly||0).toFixed(2)}</td><td>{t.days}</td><td>{t.hours.toFixed(2)}</td><td>{toCurrency(t.earnings)}</td></tr>
                );})}
              </tbody>
            </table>
          </div>
          <div style={{overflowX:'auto', marginTop:12}}>
            <h4>All Work Sessions</h4>
            <table className="table">
              <thead><tr><th>Date</th><th>Contract</th><th>Type</th><th>Hours</th><th>Hourly (€)</th><th>Earnings</th></tr></thead>
              <tbody>
                {sessions.map(s=>{ const c = contracts.find(x=>x.id===s.contractId)||{} as any; const earning = Number(s.hours||0)*Number(c.hourly||0); return (
                  <tr key={s.id}><td>{s.date}</td><td>{(c as any).name||'(unnamed)'}</td><td>{(c as any).contractType||''}</td><td>{Number(s.hours||0).toFixed(2)}</td><td>{Number((c as any).hourly||0).toFixed(2)}</td><td>{toCurrency(earning)}</td></tr>
                );})}
                {!sessions.length && <tr><td colSpan={6} style={{textAlign:'center', color:'#6b7280'}}>No sessions logged yet.</td></tr>}
              </tbody>
            </table>
          </div>
          <div className="small" style={{textAlign:'center', marginTop:8}}>Data stored on server (if enabled) until you delete/reset. Otherwise stored locally per user.</div>
        </section>
      </main>
    </div>
  );
}
