'use client';
import React, { useEffect, useState } from 'react';

async function api(path:string, method='GET', body?:any){
  const headers:any = { 'Content-Type':'application/json' };
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export default function ResetPage(){
  const [token,setToken] = useState('');
  const [password,setPassword] = useState('');
  const [ok,setOk] = useState<string|false>(false);
  const [err,setErr] = useState('');

  useEffect(()=>{
    const sp = new URLSearchParams(window.location.search);
    setToken(sp.get('token') || '');
  },[]);

  async function handleSubmit(e:any){
    e.preventDefault(); setErr(''); setOk(false);
    try{
      await api('/api/reset','POST',{ token, password });
      setOk('Password reset successful. You can close this tab and log in.');
    }catch(e:any){ setErr(e.message || String(e)); }
  }

  return (
    <div style={{maxWidth:420, margin:'40px auto', background:'#fff', border:'1px solid #e5e7eb', borderRadius:16, padding:20}}>
      <h2>Password Reset</h2>
      <form onSubmit={handleSubmit} style={{display:'grid', gap:8}}>
        <label><div style={{fontSize:12,color:'#6b7280'}}>New Password</div><input value={password} onChange={e=>setPassword((e.target as HTMLInputElement).value)} type="password" style={{width:'100%',padding:'10px 12px',border:'1px solid #d1d5db',borderRadius:12}}/></label>
        <button style={{padding:'10px 14px', borderRadius:12, background:'#111827', color:'#fff', fontWeight:600}}>Set Password</button>
        {ok && <div style={{fontSize:12, color:'#065f46'}}>{ok}</div>}
        {err && <div style={{fontSize:12, color:'#b91c1c'}}>{err}</div>}
      </form>
    </div>
  );
}
